#EXAMPLES.basic

The three examples are thougth to be executed in the interactive console, since they show explicit graphical information
through matplotlib and the standard plot library of python. The examples do not access any file.


#############
pythonBars.py
#############

A program that shows a bar plot with error bars with random data and using matplotlib
(extracted from http://matplotlib.org/examples/index.html)


#############
multiPlot.py
#############

This program plots multiple subplots in the same plot using matplotlib.
(extracted from http://matplotlib.org/examples/index.html)


################
colossusBasic.py
################

This program uses Colossus, the python package developed by iMath Research for parallel processing, to show the advantages
of parallel computing. This particular example sums the prime numbers contained in a list of randomly generated numbers.
The example uses the ParallelList class, which implements a Single Program, Multiple Data (SPMD) approach to compute the 
operations. 

ParallelList is an im-mem clsss that retains all data in memory. Only two operatins must be implemented: 

processElement: will be called once for each element of the list.
merge: will be called as many times as partial results are generated. It is used to combine the solution of multiple processes.

For more information about Colossus, please contact imath research at info@imathresearch.com

