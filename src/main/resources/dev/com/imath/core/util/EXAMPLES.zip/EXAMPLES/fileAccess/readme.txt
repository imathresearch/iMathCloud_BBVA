In this folder there are some examples on how to access data files that you have in your space.
When executing a python fils as job, all generated output files will be catched by the system and will be included in your account.
Moreover, standard output and error output will be saved in files out.txt and err.txt with the jobid as a prefix. 
This is not the case when executing the python file in the console, which will plot outputs, errors and plots in the same screen.

#############
irisPlot.py
#############

This examples read the .csv files and plots some decision tree analysis using paired features.
