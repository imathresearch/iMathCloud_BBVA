
"""
@author iMath
"""
import sys

import math
import random
import time
import unittest
import Colossus.core.kernel.parallel

class SumPrimesParallel(Colossus.core.kernel.parallel.ParallelList):
    
    def processElement(self,x, id=None):
        if (self.isprime(x)):
            return x
        return 0
    
    def merge(self,out1,out2, id=None):
        return out1 + out2
      
      
    def getCommandParameters(self) :
    	pass
      
    
    def prepareClientData(self):
    	pass
    
    def isprime(self,n):
        """Returns True if n is prime and False otherwise"""
        if not isinstance(n, int):
            raise TypeError("argument passed to is_prime is not of 'int' type")
        if n < 2:
            return False
        if n == 2:
            return True
        maxim = int(math.ceil(math.sqrt(n)))
        i = 2
        while i <= maxim:
            if n % i == 0:
                return False
            i += 1
        return True
        
def test_main():
        n = 4000000
        data = [random.randint(0,1000) for _ in range(0,n)]
        aux = SumPrimesParallel(data)
        times = [0,0,0,0]
        #print aux.data
        start_time = time.time()
        res1 = aux.startProcess()
        times[0] = time.time()-start_time
        print "The result is " + str(res1)
        print "elapsed time now: ", times[0]
		
        start_time = time.time()
        res1 = aux.startProcess(6)
        times[1] = time.time()-start_time
        print "The result is " + str(res1)
        print "elapsed time now: ", times[1]
        
        start_time = time.time()
        res1 = aux.startProcess(3)
        times[2] = time.time()-start_time
        print "The result is " + str(res1)
        print "elapsed time now: ", times[2]
        
        start_time = time.time()
        res3 = aux.startProcess(1)
        times[3] = time.time()-start_time
        print "The result is " + str(res3)
        print "elapsed time NO PARALLEL: ", times[3]
        
        plot([8,6,3,1],times)
        show()
        
        
test_main()
